digraph {
    "viewdirection" [shape=box];
    "multiply" [shape=box];
    "noise3d" [shape=box];
    "contrast" [shape=box];
    "clamp" [shape=box];
    "convert" [shape=box];
    "convert" -> "output" [label=""];
    "clamp" -> "convert" [label="in"];
    "contrast" -> "clamp" [label="in"];
    "noise3d" -> "contrast" [label="in"];
    "multiply" -> "noise3d" [label="position"];
    "viewdirection" -> "multiply" [label="in1"];
}
